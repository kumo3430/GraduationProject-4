//
//  HabitTrackingIndicatorCardView.swift
//  GraduationProject
//
//  Created by heonrim on 2023/10/2.
//
import SwiftUI

struct HabitTrackingIndicatorCardView: View {
    @EnvironmentObject var pinnedData: PinnedTaskData

    var pinnedTask: HabitTask? {
        //改成從資料庫抓取
        return nil
    }
    
    // 假設的完成度
    var completionRate: Double = 0.7

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(pinnedTask?.name ?? "未知任務")
                .font(.headline)
                .foregroundColor(Color(hex: "#574D38"))
            
            ProgressBar(value: completionRate)
                .frame(height: 30)
                .padding(.top, 10)
            
            Text("\(Int(completionRate * 100))%")
                .font(.subheadline)
                .foregroundColor(Color(hex: "#545439"))
                .padding(.top, 10)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.white)
        .cornerRadius(10)
    }
}


#Preview {
    HabitTrackingIndicatorCardView().environmentObject(PinnedTaskData())

}
