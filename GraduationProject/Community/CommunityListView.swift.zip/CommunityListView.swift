//
//  CommunityListView.swift
//  GraduationProject
//
//  Created by heonrim on 2023/10/27.
//

import SwiftUI

struct Community: Identifiable {
    enum Category: String, CaseIterable {
        case 學習, 運動, 作息, 飲食
    }
    
    var id = UUID()
    var name: String
    var description: String
    var memberCount: Int
    var image: String
    var category: Category
}

extension Color {
    static let morandiPink = Color(red: 180/255, green: 120/255, blue: 140/255)
    static let morandiBlue = Color(red: 100/255, green: 120/255, blue: 140/255)
    static let morandiGreen = Color(red: 172/255, green: 210/255, blue: 194/255)
    static let morandiBackground = Color(red: 244/255, green: 244/255, blue: 244/255)
}

struct CommunityListView: View {
    @State private var selectedSegment = 0
    @State private var selectedCategory = 0
    @State private var searchText: String = ""
    @State private var showingNotifications = false
    
    // Sample data for the joined communities
    let joinedCommunities: [Community] = [
        Community(name: "徒步探險", description: "一起徒步，感受大自然", memberCount: 41, image: "hikingadventures", category: .運動),
        Community(name: "冥想與平靜", description: "冥想帶來內心平靜", memberCount: 36, image: "meditationpeace", category: .作息),
        Community(name: "膳食多元化", description: "嘗試各種健康飲食", memberCount: 34, image: "diversemeals", category: .飲食),
        Community(name: "日常瑜伽", description: "瑜伽成為日常一部分", memberCount: 45, image: "dailyyoga", category: .運動),
        Community(name: "放鬆舒眠", description: "學習放鬆，享受深眠", memberCount: 47, image: "relaxsleep", category: .作息),
    ]
    
    // Sample data for available communities
    let availableCommunities: [Community] = [
        Community(name: "騎行樂趣", description: "騎自行車，保持活力", memberCount: 48, image: "cyclingfun", category: .運動),
        Community(name: "夜晚冥想", description: "深夜冥想，平靜思緒", memberCount: 40, image: "nightmeditation", category: .作息),
        Community(name: "健康飲食家族", description: "家庭共享健康飲食", memberCount: 50, image: "familyhealth", category: .飲食),
        Community(name: "健走社團", description: "一起健走，健康生活", memberCount: 44, image: "walktogether", category: .運動),
        Community(name: "靈感早晨", description: "清晨靈感，創造力無限", memberCount: 49, image: "inspiredmorning", category: .作息),
        Community(name: "烤食探索", description: "烤食愛好者的聚會", memberCount: 33, image: "grillingexplore", category: .飲食),
        Community(name: "健康生活愛好者", description: "探索健康生活的愛好者", memberCount: 47, image: "healthenthusiast", category: .飲食),
        Community(name: "自然愛好者", description: "尋找大自然的美麗", memberCount: 45, image: "naturelover", category: .作息),
        Community(name: "水果嘗試者", description: "品味各種水果的美味", memberCount: 41, image: "fruitexplorer", category: .飲食),
        Community(name: "日常鍛鍊", description: "持之以恆的運動", memberCount: 43, image: "dailyexercise", category: .運動),
        Community(name: "睡前冥想", description: "準備好入眠的冥想", memberCount: 39, image: "bedtimemeditation", category: .作息),
        Community(name: "營養健康分享", description: "分享營養知識和食譜", memberCount: 50, image: "nutritionhealth", category: .飲食),
        Community(name: "團隊運動", description: "一起挑戰，團結力量大", memberCount: 46, image: "teamsports", category: .運動),
        Community(name: "輕食探索者", description: "探索輕食的多樣性", memberCount: 47, image: "lighteats", category: .飲食),
        Community(name: "早晨靈感創作", description: "早晨創意發想的好時光", memberCount: 44, image: "morningcreativity", category: .作息),
        Community(name: "戶外冒險家", description: "冒險愛好者的聚會", memberCount: 49, image: "outdooradventures", category: .作息),
        Community(name: "休息日放鬆", description: "休息日輕鬆，保持活力", memberCount: 48, image: "relaxationday", category: .作息),
    ]
    // Sample data for recommended communities
    let recommendedCommunities: [Community] = [
        Community(name: "跑步愛好者", description: "一起鍛煉身體，激發活力", memberCount: 45, image: "running", category: .運動),
        Community(name: "健康飲食分享", description: "探討營養均衡的飲食方式", memberCount: 38, image: "healthyeating", category: .飲食),
        Community(name: "早鳥學習團", description: "清晨學習，提升自己", memberCount: 48, image: "earlybird", category: .學習),
        Community(name: "冥想心靈", description: "學習冥想，平靜內心", memberCount: 40, image: "meditation", category: .作息),
        Community(name: "健身新手村", description: "健身入門，互相鼓勵", memberCount: 50, image: "fitnessbeginner", category: .運動),
        Community(name: "健康烹飪秘笈", description: "健康飲食的烹飪技巧", memberCount: 32, image: "cookinghealth", category: .飲食),
        Community(name: "早起早睡", description: "培養良好的生活習慣", memberCount: 46, image: "earlyhabits", category: .作息),
        Community(name: "瑜伽之旅", description: "探索身心平衡的旅程", memberCount: 44, image: "yogajourney", category: .運動),
        Community(name: "均衡生活分享", description: "分享維持均衡生活的方法", memberCount: 39, image: "balancedlife", category: .作息),
        Community(name: "蔬食愛好者", description: "推崇蔬食生活方式", memberCount: 47, image: "vegetarian", category: .飲食),
        Community(name: "每日小步走", description: "每天行走，保持健康", memberCount: 42, image: "dailywalks", category: .運動),
        Community(name: "心靈鍛鍊", description: "提升內在力量和平靜", memberCount: 37, image: "mindtraining", category: .作息),
        Community(name: "瑜伽愛好者", description: "練習瑜伽，活力滿滿", memberCount: 49, image: "yogalove", category: .運動),
        Community(name: "健康生活分享", description: "分享促進健康的生活方式", memberCount: 35, image: "healthyliving", category: .飲食),
        Community(name: "早安好習慣", description: "建立美好的早晨習慣", memberCount: 43, image: "goodmorninghabits", category: .作息),
    ]
    
    // Sample data for popular communities
    let popularCommunities: [Community] = [
        Community(name: "均衡飲食計畫", description: "打造均衡飲食計畫", memberCount: 43, image: "balanceddietplan", category: .飲食),
        Community(name: "團體瑜伽", description: "共同練習瑜伽的樂趣", memberCount: 50, image: "groupyoga", category: .運動),
        Community(name: "健康心靈", description: "注重心靈健康", memberCount: 42, image: "mindfulhealth", category: .作息),
        Community(name: "夜間散步", description: "夜晚散步，享受寧靜", memberCount: 46, image: "nightwalks", category: .作息),
        Community(name: "瑜伽冥想聚會", description: "瑜伽和冥想的完美結合", memberCount: 45, image: "yogameditation", category: .運動),
        Community(name: "健身達人", description: "健身達人的聚會", memberCount: 40, image: "fitnessgurus", category: .運動),
        Community(name: "食材探索", description: "探索各種美味食材", memberCount: 42, image: "ingredientexploration", category: .飲食),
        Community(name: "天然飲食方式", description: "崇尚天然飲食方式", memberCount: 48, image: "naturaldiet", category: .飲食),
        Community(name: "規律運動", description: "堅持規律運動", memberCount: 44, image: "regularfitness", category: .運動),]
    
    var body: some View {
        NavigationView {
            VStack {
                Picker("", selection: $selectedSegment) {
                    Text("已加入").tag(0)
                    Text("探索").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                
                if selectedSegment == 0 {
                    ScrollView {
                        SearchBar(text: $searchText, placeholder: "搜索社群")
                            .padding(.vertical, 5)
                        SectionView(title: "已加入的社群", communities: joinedCommunities, searchText: $searchText)
                    }
                } else {
                    ScrollView {
                        SearchBar(text: $searchText, placeholder: "搜索社群")
                            .padding(.vertical, 5)
                        Picker("Category", selection: $selectedCategory) {
                            Text("推薦").tag(0)
                            Text("熱門").tag(1)
                            Text("全部").tag(2)
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding(.horizontal)
                        
                        if selectedCategory == 0 {
                            SectionView(title: "推薦社群", communities: recommendedCommunities, searchText: $searchText)
                        } else if selectedCategory == 1 {
                            SectionView(title: "熱門社群", communities: popularCommunities, searchText: $searchText)
                        } else {
                            SectionView(title: "全部社群", communities: availableCommunities, searchText: $searchText)
                        }
                    }
                }
            }
            .navigationBarItems(
                leading: NotificationButtonView(showingNotifications: $showingNotifications),
                trailing: NavigationLink(destination: AddCommunityView()) {
                    Text("創建")
                        .foregroundColor(Color(red: 0.3, green: 0.5, blue: 0.7))
                }
            )
            .sheet(isPresented: $showingNotifications) {
                NotificationView()
            }
        }
    }
}

struct NotificationButtonView: View {
    @Binding var showingNotifications: Bool

    var body: some View {
        Button(action: {
            showingNotifications.toggle()
        }) {
            Image(systemName: "bell")
                .resizable()
                .scaledToFit()
                .frame(width: 25, height: 25)
                .foregroundColor(Color(red: 0.3, green: 0.5, blue: 0.7))
        }
    }
}

struct SectionView: View {
    let title: String
    let communities: [Community]
    @Binding var searchText: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text(title)
                .font(.title2)
                .padding(.leading)
                .padding(.top)
            ForEach(communities.filter {
                searchText.isEmpty ? true : $0.name.contains(searchText)
            }) { community in
                CommunityCard(community: community)
            }
        }
        .padding(.bottom)
    }
}

struct NotificationView: View {
    let notifications = [
        ("徒步探險", "王小明在「徒步探險」回覆了您的貼文"),
        ("冥想與平靜", "李小芬在「冥想與平靜」發表了一篇新貼文"),
        ("膳食多元化", "張大偉在「膳食多元化」說您的貼文讚"),
        ("日常瑜伽", "陳小英剛加入了「日常瑜伽」"),
        ("放鬆舒眠", "楊大明在「放鬆舒眠」發表了一篇新貼文"),
        ("騎行樂趣", "吳小玲在「騎行樂趣」發表了一篇新貼文"),
        ("夜晚冥想", "鄭小強在「夜晚冥想」發表了一篇新貼文")
    ]

    var body: some View {
        List(notifications, id: \.0) { (community, message) in
            HStack {
                Image(community)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40)
                    .background(Color.morandiGreen)
                    .clipShape(Circle())
                VStack(alignment: .leading, spacing: 5) {
                    Text("社群通知")
                        .font(.headline)
                        .foregroundColor(Color.morandiBlue)
                    Text(message)
                        .font(.subheadline)
                        .foregroundColor(Color.morandiPink)
                }
                Spacer()
            }
            .padding()
            .background(RoundedRectangle(cornerRadius: 15).fill(Color.white).shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 10))
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    var placeholder: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
            TextField(placeholder, text: $text)
                .foregroundColor(.primary)
                .padding(10)
        }
        .padding(8)
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.gray.opacity(0.2)))
        .padding(.horizontal)
    }
}

struct CommunityCard: View {
    let community: Community
    
    var body: some View {
        NavigationLink(destination: Text(community.name)) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color.white)
                    .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 10)
                    .frame(height: 140)
                
                HStack {
                    Image(community.image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .background(Color.morandiGreen)
                        .clipShape(Circle())
                    
                    VStack(alignment: .leading, spacing: 5) {
                        Text(community.name)
                            .font(.headline)
                            .foregroundColor(Color.morandiBlue)
                        Text(community.description)
                            .font(.subheadline)
                            .foregroundColor(Color.morandiBlue)
                        Text("\(community.memberCount) members")
                            .font(.footnote)
                            .foregroundColor(Color.morandiPink.opacity(0.8))
                    }
                    Spacer()
                }
                .padding()
            }
            .buttonStyle(PlainButtonStyle())
        }
    }
}

struct AddCommunityView: View {
    @State private var name: String = ""
    @State private var description: String = ""
    @State private var selectedCategory: Community.Category = .學習  // Use picker for category
    @State private var coverPhoto: Image? = nil
    
    var body: some View {
        Form {
            Section(header: Text("基本資訊").foregroundColor(Color.morandiBlue)) {
                TextField("社群名稱", text: $name)
                TextField("描述", text: $description)
            }
            
            Section(header: Text("分類").foregroundColor(Color.morandiBlue)) {
                Picker("選擇分類", selection: $selectedCategory) {
                    ForEach(Community.Category.allCases, id: \.self) {
                        Text($0.rawValue)
                    }
                }
                .pickerStyle(MenuPickerStyle())
            }
            
            Section(header: Text("封面照片").foregroundColor(Color.morandiBlue)) {
                Text("選擇封面照片")
            }
            
            Button(action: {}) {
                Text("新增社群")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .background(LinearGradient(gradient: Gradient(colors: [Color.morandiPink, Color.morandiBlue]), startPoint: .leading, endPoint: .trailing))
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            .buttonStyle(PlainButtonStyle())
            .padding(.top)
        }
    }
}


struct CommunityListView_Previews: PreviewProvider {
    static var previews: some View {
        CommunityListView()
    }
}
